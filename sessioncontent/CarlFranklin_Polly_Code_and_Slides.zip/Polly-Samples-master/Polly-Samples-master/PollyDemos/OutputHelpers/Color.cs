﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PollyDemos.OutputHelpers
{
    public enum Color
    {
        Default,
        Green,
        Red,
        Yellow,
        Magenta,
        White
    }

}
