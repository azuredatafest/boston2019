﻿// User defined function returning UPPER case result of input string.
function upperCaseFunc(text) {

    var result = text.toUpperCase();

    //Returning modified result
    return result;
}